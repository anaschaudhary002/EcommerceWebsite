import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Home from './components/Home';
import Shop from './components/Shop';
import ShopDetail from './components/ShopDetail';
import ShoppingCart from './components/ShoppingCart';
import CheckOut from './components/CheckOut';
import Contact from './components/Contact';
import Error from './Error';
import Admin from './components/Admin';
import MainCategories from './components/admin/MainCategories';
import AddMainCategories from './components/admin/AddMainCategories';
import UpdateMainCategories from './components/admin/UpdateMainCategories';
import SubCategories from './components/admin/SubCategories';
import AddSubCategories from './components/admin/AddSubCategories';
import UpdateSubCategories from './components/admin/UpdateSubCategories';
import Brand from './components/admin/Brand';
import AddBrand from './components/admin/AddBrand';
import UpdateBrand from './components/admin/UpdateBrand';






function App() {
  return (
    <>
    <BrowserRouter>
      <Header/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/shop' element={<Shop/>}/>
        <Route path='/shopdetail' element={<ShopDetail/>}/>
        <Route path='/shoppingcart' element={<ShoppingCart/>}/>
        <Route path='/checkout' element={<CheckOut/>}/>
        <Route path='/contact' elementBrand/>
        <Route path='/admin' element={<Admin/>}/>
        <Route path='/main-categories' element={<MainCategories/>}/>
        <Route path='/addmain-categories' element={<AddMainCategories/>}/>
        <Route path='/updatemain-categories/:id' element={<UpdateMainCategories/>}/>
        <Route path='/sub-categories' element={<SubCategories/>}/>
        <Route path='/addsub-categories' element={<AddSubCategories/>}/>
        <Route path='/updatesub-categories/:id' element={<UpdateSubCategories/>}/>
        <Route path='/brand' element={<Brand/>}/>
        <Route path='/add-brand' element={<AddBrand/>}/>
        <Route path='/update-brand/:id' element={<UpdateBrand/>}/>
        <Route path='*' element={<Error/>}/>
      </Routes>
      <Footer/>
      </BrowserRouter>
    </>
  );
}

export default App;
