import { ADD_SUBCATEGORY_RED, DELETE_SUBCATEGORY_RED, GET_SUBCATEGORY_RED, UPDATE_SUBCATEGORY_RED } from "../Constants"

export default function SubCategoryReducer(state = [], action) {
    switch (action.type) {
        case ADD_SUBCATEGORY_RED:
            var newState = state
            newState.push(action.payload)
            return newState
        case GET_SUBCATEGORY_RED:
            return action.payload
        case DELETE_SUBCATEGORY_RED:
            var newState = state.filter((item) => item.id !== action.payload.id)
            return newState
        case UPDATE_SUBCATEGORY_RED:
            var newState = state
            var index = newState.find((x) => x.id === action.payload.id)
            newState[index] = action.payload
            return newState
        default:
            return state
    }
}

// export default function MainCategoryReducer(state=[],action){
//     if(action.type===ADD_MAINCATEGORY_RED){
//         let newState=state
//         newState.push(action.payload)
//         return newState
//     }else if(action.type===GET_MAINCATEGORY_RED){
//         return action.payload
//     }else{
//         return state
//     }

//     }
