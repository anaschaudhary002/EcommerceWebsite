import { combineReducers } from "@reduxjs/toolkit";
import MainCategoryReducer from "./MainCategoryReducer";
import SubCategoryReducer from "./SubCategoryReducer";
import BrandReducer from "./BrandReducer";


export default combineReducers({
    MainCategoryStateData:MainCategoryReducer,
    SubCategoryStateData:SubCategoryReducer,
    BrandStateData:BrandReducer,
})