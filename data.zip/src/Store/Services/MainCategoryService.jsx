export async function addMainCategoryAPI(data){
    var response=await fetch("/mainCategory",{
        method:"post",
        headers:{
            "content-type":"application/json"  
        },
        body: JSON.stringify(data)
    })
    return await response.json()
}

export async function getMainCategoryAPI(){
    var response=await fetch("/mainCategory",{
        method:"get",
        headers:{
            "content-type":"application/json"
        },
    })
    return await response.json()
}
export async function updateMainCategoryAPI(data){
    var response=await fetch("/mainCategory/"+data.id,{
        method:"put",
        headers:{
            "content-type":"application/json"
        },
        body: JSON.stringify(data)
    })
    return await response.json()
}

export async function deleteMainCategoryAPI(data){
    var response=await fetch("/mainCategory/"+data.id,{
        method:"delete",
        headers:{
            "content-type":"application/json"
        },
        
    })
    return await response.json()
}



// headers content type tells the server/client the type of data you are receving for example HTML,CSS,JSON etc