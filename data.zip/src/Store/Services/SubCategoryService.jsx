export async function addSubCategoryAPI(data){
    var response=await fetch("/subCategory",{
        method:"post",
        headers:{
            "content-type":"application/json"  
        },
        body: JSON.stringify(data)
    })
    return await response.json()
}

export async function getSubCategoryAPI(){
    var response=await fetch("/subCategory",{
        method:"get",
        headers:{
            "content-type":"application/json"
        },
    })
    return await response.json()
}
export async function updateSubCategoryAPI(data){
    var response=await fetch("/subCategory/"+data.id,{
        method:"put",
        headers:{
            "content-type":"application/json"
        },
        body: JSON.stringify(data)
    })
    return await response.json()
}

export async function deleteSubCategoryAPI(data){
    var response=await fetch("/subCategory/"+data.id,{
        method:"delete",
        headers:{
            "content-type":"application/json"
        },
        
    })
    return await response.json()
}



// headers content type tells the server/client the type of data you are receving for example HTML,CSS,JSON etc