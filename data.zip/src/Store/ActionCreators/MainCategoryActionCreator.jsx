import {ADD_MAINCATEGORY} from "../Constants"
import {GET_MAINCATEGORY} from "../Constants"
import {GET_SINGLE_MAINCATEGORY} from "../Constants"
import {UPDATE_MAINCATEGORY} from "../Constants"
import {DELETE_MAINCATEGORY} from "../Constants"

export function addMainCategory(data) {
    return {
        type: ADD_MAINCATEGORY,
        payload: data
    }
}

export function getMainCategory() {
    return {
        type: GET_MAINCATEGORY
    }
}

export function updateMainCategory(data) {
    return {
        type: UPDATE_MAINCATEGORY,
        payload: data
    }
}

export function deleteMainCategory(data) {
    return {
        type: DELETE_MAINCATEGORY,
        payload: data
    }
}