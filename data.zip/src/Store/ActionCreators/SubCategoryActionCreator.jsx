import {ADD_SUBCATEGORY} from "../Constants"
import {GET_SUBCATEGORY} from "../Constants"
import {UPDATE_SUBCATEGORY} from "../Constants"
import {DELETE_SUBCATEGORY} from "../Constants"

export function addSubCategory(data) {
    return {
        type: ADD_SUBCATEGORY,
        payload: data
    }}

export function getSubCategory() {
    return {
        type: GET_SUBCATEGORY
    }
}

export function updateSubCategory(data) {
    return {
        type: UPDATE_SUBCATEGORY,
        payload: data
    }
}

export function deleteSubCategory(data) {
    return {
        type: DELETE_SUBCATEGORY,
        payload: data
    }
}