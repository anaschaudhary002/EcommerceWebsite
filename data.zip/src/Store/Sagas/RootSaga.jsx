import {all} from "redux-saga/effects"
import {MainCategorySaga} from "./MainCategorySagas"
import {SubCategorySaga} from "./SubCategorySagas"
import {BrandSaga} from "./BrandSagas"

export default function* RootSaga(){
    yield all([
        MainCategorySaga(),
        SubCategorySaga(),
        BrandSaga()
    ])
}