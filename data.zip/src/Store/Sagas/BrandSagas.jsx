import { ADD_BRAND, ADD_BRAND_RED } from "../Constants"
import { GET_BRAND, GET_BRAND_RED } from "../Constants"
import { DELETE_BRAND,DELETE_BRAND_RED } from "../Constants"
import { UPDATE_BRAND,UPDATE_BRAND_RED } from "../Constants"
import { addBrandAPI } from "../Services/BrandService"
import { getBrandAPI } from "../Services/BrandService"
import { deleteBrandAPI } from "../Services/BrandService"
import { updateBrandAPI } from "../Services/BrandService"

import { takeEvery, put } from "redux-saga/effects"


{/*Sagas contain decorator function i.e:function*
*Saga work on two basis (watcher) and (Executer) watcher make sure and contain info about which function get hit 
while Executer execute that function which got hit and make call to reducer*/}


{/*executer function*/ }

function* addBrandSaga(action) {
    var response = yield addBrandAPI(action.payload)
    yield put({type:ADD_BRAND_RED,payload: response })
}

function* getBrandSaga(action) {
    var response = yield getBrandAPI()
    yield put({type:GET_BRAND_RED,payload: response })
}

function* updateBrandSaga(action) {
    var response = yield updateBrandAPI(action.payload)
    yield put({type:UPDATE_BRAND_RED,payload: response })
}

function* deleteBrandSaga(action) {
    var response = yield deleteBrandAPI(action.payload)
    yield put({type:DELETE_BRAND_RED,payload: action.payload })
}

{/*watcher function*/ }
export function* BrandSaga() {
    yield takeEvery(ADD_BRAND, addBrandSaga)
    yield takeEvery(GET_BRAND, getBrandSaga)
    yield takeEvery(UPDATE_BRAND, updateBrandSaga)
    yield takeEvery(DELETE_BRAND, deleteBrandSaga)
}