import { ADD_SUBCATEGORY, ADD_SUBCATEGORY_RED } from "../Constants"
import { GET_SUBCATEGORY, GET_SUBCATEGORY_RED } from "../Constants"
import { DELETE_SUBCATEGORY,DELETE_SUBCATEGORY_RED } from "../Constants"
import { UPDATE_SUBCATEGORY,UPDATE_SUBCATEGORY_RED } from "../Constants"
import { addSubCategoryAPI } from "../Services/SubCategoryService"
import { getSubCategoryAPI } from "../Services/SubCategoryService"
import { deleteSubCategoryAPI } from "../Services/SubCategoryService"
import { updateSubCategoryAPI } from "../Services/SubCategoryService"

import { takeEvery, put } from "redux-saga/effects"


{/*Sagas contain decorator function i.e:function*
*Saga work on two basis (watcher) and (Executer) watcher make sure and contain info about which function get hit 
while Executer execute that function which got hit and make call to reducer*/}


{/*executer function*/ }

function* addSubCategorySaga(action) {
    var response = yield addSubCategoryAPI(action.payload)
    yield put({type:ADD_SUBCATEGORY_RED,payload: response })
}

function* getSubCategorySaga(action) {
    var response = yield getSubCategoryAPI()
    yield put({type:GET_SUBCATEGORY_RED,payload: response })
}

function* updateSubCategorySaga(action) {
    var response = yield updateSubCategoryAPI(action.payload)
    yield put({type:UPDATE_SUBCATEGORY_RED,payload: response })
}

function* deleteSubCategorySaga(action) {
    var response = yield deleteSubCategoryAPI(action.payload)
    yield put({type:DELETE_SUBCATEGORY_RED,payload: action.payload })
}

{/*watcher function*/ }
export function* SubCategorySaga() {
    yield takeEvery(ADD_SUBCATEGORY, addSubCategorySaga)
    yield takeEvery(GET_SUBCATEGORY, getSubCategorySaga)
    yield takeEvery(UPDATE_SUBCATEGORY, updateSubCategorySaga)
    yield takeEvery(DELETE_SUBCATEGORY, deleteSubCategorySaga)
}