import { ADD_MAINCATEGORY, ADD_MAINCATEGORY_RED } from "../Constants"
import { GET_MAINCATEGORY, GET_MAINCATEGORY_RED } from "../Constants"
import { DELETE_MAINCATEGORY,DELETE_MAINCATEGORY_RED } from "../Constants"
import { UPDATE_MAINCATEGORY,UPDATE_MAINCATEGORY_RED } from "../Constants"
import { addMainCategoryAPI } from "../Services/MainCategoryService"
import { getMainCategoryAPI } from "../Services/MainCategoryService"
import { deleteMainCategoryAPI } from "../Services/MainCategoryService"
import { updateMainCategoryAPI } from "../Services/MainCategoryService"

import { takeEvery, put } from "redux-saga/effects"


{/*Sagas contain decorator function i.e:function*
*Saga work on two basis (watcher) and (Executer) watcher make sure and contain info about which function get hit 
while Executer execute that function which got hit and make call to reducer*/}


{/*executer function*/ }

function* addMainCategorySaga(action) {
    var response = yield addMainCategoryAPI(action.payload)
    yield put({type:ADD_MAINCATEGORY_RED,payload: response })
}

function* getMainCategorySaga(action) {
    var response = yield getMainCategoryAPI()
    yield put({type:GET_MAINCATEGORY_RED,payload: response })
}

function* updateMainCategorySaga(action) {
    var response = yield updateMainCategoryAPI(action.payload)
    yield put({type:UPDATE_MAINCATEGORY_RED,payload: response })
}

function* deleteMainCategorySaga(action) {
    var response = yield deleteMainCategoryAPI(action.payload)
    yield put({type:DELETE_MAINCATEGORY_RED,payload: action.payload })
}

{/*watcher function*/ }
export function* MainCategorySaga() {
    yield takeEvery(ADD_MAINCATEGORY, addMainCategorySaga)
    yield takeEvery(GET_MAINCATEGORY, getMainCategorySaga)
    yield takeEvery(UPDATE_MAINCATEGORY, updateMainCategorySaga)
    yield takeEvery(DELETE_MAINCATEGORY, deleteMainCategorySaga)
}