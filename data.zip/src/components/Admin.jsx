import React from 'react'
import AdminDetail from './AdminDetail'

export default function Admin() {
    return (
        <>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-3">
                        <AdminDetail/>
                    </div>
                    <div className="col-md-9">
                        <h2 className='bg-primary py-2'>Admin Profile</h2>
                        <div className="row">
                            <div className="col-md-6">
                                <img src='/assets/img/user.jpg' width={'100%'}></img>
                            </div>
                            <div className="col-md-6" style={{display:"flex",justifyContent:"center",alignItems:"center"}}>
                                <table >
                                    <tr>
                                        <div>
                                        <th>Name:</th>
                                        <td>Mohd Anas Choudhary</td>
                                        </div>
                                    </tr>
                                    <tr>
                                        <div>
                                        <th>Email:</th>
                                        <td>anaschaudhary002@gmail.com</td>
                                        </div>
                                    </tr>
                                    <tr>
                                        <div>
                                        <th>Role:</th>
                                        <td>Admin</td>
                                        </div>
                                    </tr>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </>
    )
}
