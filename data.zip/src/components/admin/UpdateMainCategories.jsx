import React, { useEffect, useState } from 'react'
import AdminDetail from '../AdminDetail'

import {  updateMainCategory, getMainCategory } from '../../Store/ActionCreators/MainCategoryActionCreator'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate,useParams } from 'react-router-dom'

export default function UpdateMainCategories() {
  const [data, setData] = useState({
    name: ""
  })
  var {id}=useParams()
  var dispatch = useDispatch()
  var navigate=useNavigate()
  var allMainCategories = useSelector((state) => state.MainCategoryStateData)
  const getInputData = (e) => {
    var { name, value } = e.target
    setData((old) => {
      return {
        ...old,
        [name]: value
      }
    })
  }

  const postData = (e) => {
    e.preventDefault()
    var item=allMainCategories.find(x=>x.name && x.name.toLowerCase()===data.name.toLowerCase())
    if(item){
      alert("main category is already exist")
    }
    else{
      dispatch (updateMainCategory({id:data.id,name:data.name}))
    return navigate("/main-categories")
    }
  }
  function getAPIData() {
    dispatch(getMainCategory())
    if(allMainCategories.length){
      var item=allMainCategories.find((x)=>x.id===parseInt(id))
      if(item){
        setData((old)=>{
          return{
            ...old,...item
          }
        })
      }
    }
  }
  useEffect(() => {
    getAPIData()
  }, [allMainCategories.length])
  return (
    <>
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-3 col-12">
            <AdminDetail />
          </div>
          <div className="col-md-9 col-12">
            <h5 className='bg-primary text-center p-2'>Update Main Categories</h5>
            <div className=''>
              <form onSubmit={postData}>
                <div className='mb-3'>
                  <input className=' w-100 p-2' type='text' name='name' value={data.name} onChange={getInputData}></input>
                </div>
                <div className='mb-3'>
                  <button type='reset' className='btn btn-danger w-50'>Reset</button>
                  <button type='submit' className='btn btn-primary w-50'>Submit</button>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </>
  )
}
