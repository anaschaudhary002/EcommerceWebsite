import React, { useEffect } from 'react'
import AdminDetail from '../AdminDetail'
import { Link, useNavigate } from 'react-router-dom'
import { DataGrid } from '@mui/x-data-grid';
import { getSubCategory,deleteSubCategory } from '../../Store/ActionCreators/SubCategoryActionCreator'
import { useDispatch, useSelector} from 'react-redux';
import { Button } from '@mui/material';

export default function SubCategories() {
  var rows = [];
  var dispatch = useDispatch()
  var allSubCategories = useSelector((state) => state.SubCategoryStateData)
  var navigate = useNavigate()
  if (allSubCategories.length) {
    for (let item of allSubCategories.slice(1, allSubCategories.length))
      rows.push({ id: item.id, name: item.name })
  }
  function getAPIData() {
    dispatch(getSubCategory())
  }
  useEffect(() => {
    getAPIData()
  }, [allSubCategories.length])

  const columns = [
    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'name', headerName: 'Name', width: 130 },
    {
      field: 'edit',
      headerName: 'Edit',
      sortable: false,
      renderCell: ({ row }) => 
        <Button onClick={() => {
          navigate("/updatesub-categories/" + row.id)
        }}>
          <i className='fa fa-edit'></i>
        </Button>
    },
    {
      field: 'delete',
      headerName: 'Delete',
      sortable: false,
      renderCell: ({ row }) => 
        <Button onClick={() => {
          dispatch(deleteSubCategory({id:row.id}))
        }}>
          <i className='fa fa-trash'></i>
        </Button>
    
    },
  
  ];
  return (
    <>
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-3">
            <AdminDetail />
          </div>
          <div className="col-md-9">
            <div className="row py-2 mx-2">
              <div className="col-md-11  bg-primary">
                <h2 >Main Categories</h2>
              </div>
              <div className="col-md-1 py-1  bg-primary">
                <Link style={{ color: "black" }} className='fa fa-plus' to="/addsub-categories"></Link>

              </div>
              <div style={{ height: 400, width: '100%' }}>
                <DataGrid
                  rows={rows}
                  columns={columns}
                  initialState={{
                    pagination: {
                      paginationModel: { page: 0, pageSize: 5 },
                    },
                  }}
                  pageSizeOptions={[5, 10, 25]}

                />
              </div>

            </div>
          </div>
        </div>
      </div>
    </>
  )
}
