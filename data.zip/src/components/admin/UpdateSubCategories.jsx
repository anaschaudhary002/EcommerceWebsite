import React, { useEffect, useState } from 'react'
import AdminDetail from '../AdminDetail'

import {  updateSubCategory, getSubCategory } from '../../Store/ActionCreators/SubCategoryActionCreator'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate,useParams } from 'react-router-dom'

export default function UpdateSubCategories() {
  const [data, setData] = useState({
    name: ""
  })
  var {id}=useParams()
  var dispatch = useDispatch()
  var navigate=useNavigate()
  var allSubCategories = useSelector((state) => state.SubCategoryStateData)
  const getInputData = (e) => {
    var { name, value } = e.target
    setData((old) => {
      return {
        ...old,
        [name]: value
      }
    })
  }

  const postData = (e) => {
    e.preventDefault()
    var item=allSubCategories.find(x=>x.name && x.name.toLowerCase()===data.name.toLowerCase())
    if(item){
      alert("sub category is already exist")
    }
    else{
      dispatch (updateSubCategory({id:data.id,name:data.name}))
    return navigate("/sub-categories")
    }
  }
  function getAPIData() {
    dispatch(getSubCategory())
    if(allSubCategories.length){
      var item=allSubCategories.find((x)=>x.id===parseInt(id))
      if(item){
        setData((old)=>{
          return{
            ...old,...item
          }
        })
      }
    }
  }
  useEffect(() => {
    getAPIData()
  }, [allSubCategories.length])
  return (
    <>
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-3 col-12">
            <AdminDetail />
          </div>
          <div className="col-md-9 col-12">
            <h5 className='bg-primary text-center p-2'>Update Sub Categories</h5>
            <div className=''>
              <form onSubmit={postData}>
                <div className='mb-3'>
                  <input className=' w-100 p-2' type='text' name='name' value={data.name} onChange={getInputData}></input>
                </div>
                <div className='mb-3'>
                  <button type='reset' className='btn btn-danger w-50'>Reset</button>
                  <button type='submit' className='btn btn-primary w-50'>Submit</button>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </>
  )
}
