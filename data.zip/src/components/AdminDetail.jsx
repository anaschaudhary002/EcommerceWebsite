import React from 'react'
import {Link} from "react-router-dom"

export default function AdminDetail() {
    return (
        <>
            <div class="list-group">
                <button type="button" class="list-group-item list-group-item-action active">
                    Admin Home
                </button>
                <button type="button" class="list-group-item list-group-item-action">Users</button>
                <Link to="/main-categories" className="list-group-item list-group-item-action   ">Main Categories</Link>
                <Link to="/sub-categories" className="list-group-item list-group-item-action   ">Sub Categories</Link>
                <Link to="/brand" className="list-group-item list-group-item-action   ">Brands</Link>
                <Link to="/products" className="list-group-item list-group-item-action   ">Products</Link>
                <Link to="/contact-us" className="list-group-item list-group-item-action   ">Contact Us</Link>
                <Link to="/newsletter" className="list-group-item list-group-item-action   ">Newsletter</Link>

            </div>
        </>
    )
}
